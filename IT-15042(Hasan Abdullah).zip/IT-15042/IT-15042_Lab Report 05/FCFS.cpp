/// First Come First Serve Algorithm
#include<bits/stdc++.h>
#define ll long long int
#define pb push_back
using namespace std;
int main()
{
    ll process;
    cout<<"Enter The Process number: "<<endl;
    while(cin>>process)
    {
        cout<<"Enter The Burst time Sequentially: "<<endl;
        vector<ll>burst,cumu_proc;
        ll x,sum=0,wait=0,turn=0;
        double avg_wait,avg_turn;
        cumu_proc.pb(0);
        for(ll i=0;i<process;i++)
{
            cin>>x;	sum+=x;
            turn+=sum;

cumu_proc.pb(sum);
            burst.pb(x);
        }
        cout<<"Grant chart"<<endl;
        for(ll i=0;i<cumu_proc.size();i++)
        {
            wait+=cumu_proc[i];
            cout<<cumu_proc[i]<<" ";
        }
        cout<<endl;
        wait-=cumu_proc[cumu_proc.size()-1];
        avg_wait=(double)wait;
        avg_turn=(double)turn;
        printf("Average waiting time = %.2lf  \n Average turn around time = %.2lf\n",avg_wait/process,avg_turn/process);
    }
}

